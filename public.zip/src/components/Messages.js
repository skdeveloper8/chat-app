import React from 'react'

function Messages() {
  return (
    <div className='message'>

    </div>
  )
}

export default Messages